// TweenMax.to('.box1', 1, {x:450});
// TweenMax.to('.box1', 1, {x:450, y:450,
//             delay:0.2,
//             ease: Elastic.easeOut.config(1, 0.3)
//             });
TweenMax.from('.box1', 1, {x:450});
