$(document).ready(function(){

  $('div > p').css('color', 'red');

 });
