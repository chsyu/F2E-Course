$(document).ready(function(){

  $('h2').css('color', 'red');

 });
