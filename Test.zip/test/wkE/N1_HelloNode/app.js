a = 2;
b = 3;
console.log('This result is ' + a*b);
