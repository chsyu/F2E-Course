var gulp = require('gulp')

gulp.task('default', function() {
  console.log('Hello GULP !!!');
});

gulp.task('html', function() {
  console.log('HTML task ...');
});
