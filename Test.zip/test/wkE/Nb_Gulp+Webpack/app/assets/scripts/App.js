import ButtonClick from './modules/ButtonClick';

var btnClick = new ButtonClick();