document.querySelector("#byID").innerHTML="我是ID";
document.querySelector("#byID").style.color="blue";

document.querySelector(".byClass").innerHTML="我是Class";
document.querySelector(".byClass").style.fontSize="30px";

document.querySelectorAll("div")[2].innerHTML="我是Tag";
document.querySelectorAll("div")[2].style.backgroundColor="rgba(0,0,0,0.1)";
