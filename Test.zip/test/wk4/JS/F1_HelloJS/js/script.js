var name = "Sam";
alert("Hello " + name);

var sure = confirm("Are you shure?");
alert('You are ' + sure);

var opinion = prompt("Input your opinion here ..");
alert('Your opinions are ' + opinion);
