new TimelineMax()
    .to('#box1', 1, { x: 450})
    .to('#box1', 1, { x: 0})
    .to('#box1', 1, { x: 225, y: 225})
    .to('#box1', 3, { rotation: 360});
