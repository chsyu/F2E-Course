// TweenMax.to('#box1', 1, {y: 450, delay: 1});
// TweenMax.to('#box2', 1, {y: 450, delay: 2});
// TweenMax.staggerTo(['#box1', '#box2'], 1, {y: 450}, 1);
TweenMax.fromTo('#box1', 1, { x: 150 }, { x: 450});
