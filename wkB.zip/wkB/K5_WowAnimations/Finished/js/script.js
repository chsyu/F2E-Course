$(function(){
   new WOW().init();
});

